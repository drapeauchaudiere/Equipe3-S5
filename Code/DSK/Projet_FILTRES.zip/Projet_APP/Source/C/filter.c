
#include <stdio.h>
#include <math.h>
#include "filter.h"
//#include "coeffsIIR.dat"


#define IIR_NB_COEFFS 6     // Nombre total de coeffcients a & b (b0 b1 b2 a0 a1 a2)
#define IIR_NB_FILTRES 4        // Nombre de filtres
#define IIR_NB_SECTIONS_MAX 1   // nb de sections d'ordre 2 du plus gros filtre

const short IIR_COEFFS[][IIR_NB_COEFFS] = {
    // 1er filtre (ordre 4, ripple de 3dB, fc = 700Hz, fe = 44100 Hz)
        {   2048, 4096, 2048, 8192, -15230, 7114},
    // 2e filtre (ordre 4, ripple de 3dB, fc = 5000Hz, fe = 44100 Hz)
        {  2068, 4135, 2068, 8192,-8480,3013},
    // 3e filtre (ordre 4, ripple de 3dB, fc = 7000Hz, fe = 44100 Hz)
        {  7203, -14406, 7203, 8192, -5577, 2087},
    // 4e filtre (ordre 4, ripple de 3dB, fc = 1000Hz, fe = 44100 Hz)
        {   15469, -30938, 15469, 8192, -14738, 6697},
};
const short IIR_GAINS[IIR_NB_FILTRES] = {76 ,2699, 4508, 3922}; // � COMPL�TER

#pragma DATA_ALIGN(IIR_W, 4);
int IIR_W[IIR_NB_SECTIONS_MAX][3] = {0};

/*
short equilizer(short signal){

}
*/
short FPB_700(int signal){

    int y;

    //y = IIR_2ndOrder_directII(signal, &IIR_W[1][0], &IIR_COEFFS[0][0]); // y->15Q13
    y = IIR_2ndOrder_directII_ASM(signal, &IIR_W[0][0], &IIR_COEFFS[0][0]); // y->15Q13

    // Appliquer le gain global
    y = IIR_GAINS[0]*y; // 2Q13 x 15Q13 = 17Q26
    y = (y>>13);                     // y->17Q13

    return sat_16bits(y);            // y->2Q13*/
}


int FPB_5000(int signal){

    int y;

    y = IIR_2ndOrder_directII(signal, &IIR_W[0][1], &IIR_COEFFS[1][0]); // y->15Q13
    //y = IIR_2ndOrder_directII_ASM(signal, &IIR_W[1][1], &IIR_COEFFS[1][0]); // y->15Q13

    // Appliquer le gain global
   // y =IIR_GAINS[1]*y; // 2Q13 x 15Q13 = 17Q26
    //y = (y>>13);                     // y->17Q13

    return (y);            // y->2Q13*/

}

short FPH_7000(int signal){

    int y;

    //y = IIR_2ndOrder_directII_ASM(signal, &IIR_W[1][2], &IIR_COEFFS[2][0]); // y->15Q13
    y = IIR_2ndOrder_directII_ASM(signal, &IIR_W[0][2], &IIR_COEFFS[2][0]); // y->15Q13

    // Appliquer le gain global
    y = IIR_GAINS[2]*y; // 2Q13 x 15Q13 = 17Q26
    y = (y>>13);                     // y->17Q13

    return sat_16bits(y);            // y->2Q13*/

}

int FPH_1000(int signal){

    int y;

    y = IIR_2ndOrder_directII(signal, &IIR_W[0][3], &IIR_COEFFS[3][0]); // y->15Q13
    //y = IIR_2ndOrder_directII_ASM(signal, &IIR_W[1][3], &IIR_COEFFS[3][0]); // y->15Q13

    // Appliquer le gain global
    //y = IIR_GAINS[3]*y; // 2Q13 x 15Q13 = 17Q26
    //y = (y>>13);                     // y->17Q13

    return y;            // y->2Q13*/

}

short FPB_1000_5000(int signal){
    int y,temp;
    temp = FPH_1000(signal);
    y = FPB_5000(temp);
    y = (int)IIR_GAINS[1]*y; // 2Q13 x 15Q13 = 17Q26
    y = (y>>13);                     // y->17Q13

    return sat_16bits(y);
}


/***********************************************************************************
DESCRIPTION : Initialisation des variables interm�diaires w(n-i)
***********************************************************************************/

void init_w()
{
    int i, j;

    for (i=0; i<IIR_NB_SECTIONS_MAX; i++)   {
        for (j=0; j<3; j++)     IIR_W[i][j] = 0;
    }
}

/***********************************************************************************
DESCRIPTION : Permet de faire une saturation � 16bits
***********************************************************************************/

short sat_16bits(int x) {

    short r;

    if (x>(pow(2,15)-1))
        r =(short)pow(2,15)-1;
    else if (x<-pow(2,15))
        r = (short)-pow(2,15);
    else
        r = (short)x;

    return r;
}



