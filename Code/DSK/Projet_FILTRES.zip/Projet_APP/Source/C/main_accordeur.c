/* accordeur.c */
/*
  Cr�ateur:    Bruno Gagnon, M. Sc.A
  Date:        2 septembre 2009
  Revisions:   Paul Charette (automne 2016)
  	  	  	  - Chang� le nom de certains variables dans c_int11() pour rendre le
  	  	  	  	code plus compr�hensible.
  	  	  	  - Ajout� � c_int11() la capacit� de sortir les �chantillons
  	  	  	    non-filtr�s et filtr�s sur les canaux droite/gauche de OUT
  	  	  	    pour d�bugger les filtres ind�pendemment du calcul de l'erreur
  	  	  	    d'accordage.

  DESCRIPTION : 
     Code principal pour un accordeur de guitare. Permet d'�couter 
     la fr�quence fondamentale des cordes de guitare et d'obtenir 
     l'erreur sur l'accordement.

  ENTR�ES : 
	 Il y a deux types d'entr�es physiques :
     1) Signal audio branch� sur l'entr�e LINE IN du DSK. Ce signal
     correspondant � une note de guitare jou�e par un musicien. 
     2) Les s�lections de l'utilisateur provenant des boutons du DSK.

  SORTIES : 
     1) Erreur sur l'accordement de la note jou�e. Cette erreur
        est transmise sur le canal gauche de la sortie HEADPHONE du DSK.
	 2) Signal sinuso�dal correspondant � la fr�quence fondamentale
	    de la note s�lectionn�e. Ce signal est transmis sur le canal droit
		de la sortie HEADPHONE du DSK (Pour �couter il faut appuyer sur
		la DIP SWITCH #3)
*/
#include <stdio.h>
#include <math.h>
#include "filter.h"


int Fs = 44100;
int F1 = 10000;
int nb_ech = 441;
float echFiltrer700[441];
float echFiltrer1000[441];
float echFiltrer5000[441];
float echFiltrer7000[441];
short TableCos1[441];
float PI = 3.14159265359;
float output[441];
short filtrePasseBande(short x);


void main()
{
    init_w();

    while(1){
        int n;
        for (n=0; n<nb_ech; n++){



            TableCos1[n] = 100*cos(2*PI*F1*n/Fs);


            //echFiltrer700[n] = (FPB_700(TableCos1[n])/pow(2,13));
            //echFiltrer1000[n] = (FPH_1000(TableCos1[n])/pow(2,13));
            //echFiltrer5000[n] = (FPB_5000(TableCos1[n])/pow(2,13));
            //echFiltrer7000[n] = (FPH_7000(TableCos1[n])/pow(2,13));
            //echFiltrer1000[n] = (FPB_1000_5000(TableCos1[n]))/pow(2,13);
            output[n] = filtrePasseBande(TableCos1[n]);
        };

    };

}




short filtrePasseBande(short x)
{
    static short x4 = 0;
    static short x3 = 0;
    static short x2 = 0;
    static short x1 = 0;

    static short y4 = 0;
    static short y3 = 0;
    static short y2 = 0;
    static short y1 = 0;
    short y = 0;

    static const short b0 = 752;
    static const short b2 = -1504;
    static const short b4 = 752;

    static const short a0 = 10000;
    static const short a1 = -28343;
    static const short a2 = 30477;
    static const short a3 = -15080;
    static const short a4 = 3007;

    y = (b0*x + b2*x2 + b4*x4 -a1*y1 -a2*y2 -a3*y3 -a4*y4)/a0;

    x4 = x3;
    x3 = x2;
    x2 = x1;
    x1 = x;


    y4 = y3;
    y3 = y2;
    y2 = y1;
    y1 = y;
    return y;
}

