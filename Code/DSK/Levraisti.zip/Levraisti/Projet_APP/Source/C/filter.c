
#include <stdio.h>
#include <math.h>
#include "filter.h"
//#include "coeffsIIR.dat"


#define IIR_NB_COEFFS 6     // Nombre total de coeffcients a & b (b0 b1 b2 a0 a1 a2)
#define IIR_NB_FILTRES 4        // Nombre de filtres
#define IIR_NB_SECTIONS_MAX 1   // nb de sections d'ordre 2 du plus gros filtre

const short IIR_COEFFS[][IIR_NB_COEFFS] = {
    // 1er filtre (ordre 4, ripple de 3dB, fc = 700Hz, fe = 44100 Hz)
        {   164, 328, 164, 8192, -12798, 5260},
    // 2e filtre (ordre 4, ripple de 3dB, fc = 5000Hz, fe = 44100 Hz)
        {  0.5204,1.0407,0.5205, 1,0.7956,0.2858},
    // 3e filtre (ordre 4, ripple de 3dB, fc = 7000Hz, fe = 44100 Hz)
        {  0.7280, -1.4559, 0.7280, 1, -1.3805, 0.5313},
    // 4e filtre (ordre 4, ripple de 3dB, fc = 1000Hz, fe = 44100 Hz)
        {   0.9941, 1.9882, 0.9941, 1, 1.9881,0.9882},
};
const short IIR_GAINS[IIR_NB_FILTRES] = {655 ,1, 0.4771, 0.000070515}; // � COMPL�TER

#pragma DATA_ALIGN(IIR_W, 4);
int IIR_W[IIR_NB_SECTIONS_MAX][3] = {0};

/*
short equilizer(short signal){

}
*/
short FPB_700(short signal){

    int y;

    y = IIR_2ndOrder_directII_ASM(signal, &IIR_W[1][0], &IIR_COEFFS[0][0]); // y->15Q13

    // Appliquer le gain global
    y = (int)IIR_GAINS[0]*y; // 2Q13 x 15Q13 = 17Q26
    y = (y>>13);                     // y->17Q13

    return sat_16bits(y);            // y->2Q13*/
}



/*
short FPB_5000(short signal){

}

short FPH_7000(short signal){

}

short FPH_1000(short signal){

}
*/

/*
short filtrerCascadeIIR(int noCorde, short x)
{
    int n, ligne;
    int y;

    y = x;

    // Pour chacune des sections d'ordre 2 du filtre
    for (n=0; n<IIR_NB_ORDRE2[noCorde-1]; n++) {

        // filtrage par le IIR biquad de structure direct II
        ligne = IIR_NO_LIGNE[noCorde-1]+n;
        y = IIR_2ndOrder_directII_ASM(y, &IIR_W[n][0], &IIR_COEFFS[ligne][0]); // y->15Q13
    //  y = IIR_2ndOrder_directII(y, &IIR_W[n][0], &IIR_COEFFS[ligne][0]); // � CODER
    }

    // Appliquer le gain global
    y = (int)IIR_GAINS[noCorde-1]*y; // 2Q13 x 15Q13 = 17Q26
    y = (y>>13);                     // y->17Q13

    return sat_16bits(y);            // y->2Q13
}
*/

/***********************************************************************************
DESCRIPTION : Initialisation des variables interm�diaires w(n-i)
***********************************************************************************/

void init_w()
{
    int i, j;

    for (i=0; i<IIR_NB_SECTIONS_MAX; i++)   {
        for (j=0; j<3; j++)     IIR_W[i][j] = 0;
    }
}

/***********************************************************************************
DESCRIPTION : Permet de faire une saturation � 16bits
***********************************************************************************/

short sat_16bits(int x) {

    short r;

    if (x>(pow(2,15)-1))
        r =(short)pow(2,15)-1;
    else if (x<-pow(2,15))
        r = (short)-pow(2,15);
    else
        r = (short)x;

    return r;
}
