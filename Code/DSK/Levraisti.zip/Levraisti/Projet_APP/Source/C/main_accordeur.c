/* accordeur.c */
/*
  Cr�ateur:    Bruno Gagnon, M. Sc.A
  Date:        2 septembre 2009
  Revisions:   Paul Charette (automne 2016)
  	  	  	  - Chang� le nom de certains variables dans c_int11() pour rendre le
  	  	  	  	code plus compr�hensible.
  	  	  	  - Ajout� � c_int11() la capacit� de sortir les �chantillons
  	  	  	    non-filtr�s et filtr�s sur les canaux droite/gauche de OUT
  	  	  	    pour d�bugger les filtres ind�pendemment du calcul de l'erreur
  	  	  	    d'accordage.

  DESCRIPTION : 
     Code principal pour un accordeur de guitare. Permet d'�couter 
     la fr�quence fondamentale des cordes de guitare et d'obtenir 
     l'erreur sur l'accordement.

  ENTR�ES : 
	 Il y a deux types d'entr�es physiques :
     1) Signal audio branch� sur l'entr�e LINE IN du DSK. Ce signal
     correspondant � une note de guitare jou�e par un musicien. 
     2) Les s�lections de l'utilisateur provenant des boutons du DSK.

  SORTIES : 
     1) Erreur sur l'accordement de la note jou�e. Cette erreur
        est transmise sur le canal gauche de la sortie HEADPHONE du DSK.
	 2) Signal sinuso�dal correspondant � la fr�quence fondamentale
	    de la note s�lectionn�e. Ce signal est transmis sur le canal droit
		de la sortie HEADPHONE du DSK (Pour �couter il faut appuyer sur
		la DIP SWITCH #3)
*/
#include <stdio.h>
#include <math.h>
#include "filter.h"


int Fs = 44100;
int F1 = 1000;
int nb_ech = 441;
float echFiltrer700[441];
float echFiltrer1000[441];
float echFiltrer5000[441];
float echFiltrer7000[441];
int TableCos1[441];
float PI = 3.14159265359;

void main()
{
    init_w();

    while(1){
        int n;
        for (n=0; n<nb_ech; n++){
            TableCos1[n] = pow(2,13)*cos(2*PI*F1*n/Fs);
            //echFiltrer700[n] = (FPB_700(TableCos1[n])/pow(2,13));
            //echFiltrer1000[n] = (FPH_1000(TableCos1[n])/pow(2,13));
            //echFiltrer5000[n] = (FPB_5000(TableCos1[n])/pow(2,13));
            //echFiltrer7000[n] = (FPH_7000(TableCos1[n])/pow(2,13));
        };
    };

}
