
#include <stdio.h>
#include <math.h>
/*
short equilizer(short signal){

}
*/

short FPB_700(short signal);
//int _IIR_2ndOrder_directII_ASM(short, int, const short);

/*
short FPB_5000(short signal);
short FPH_7000(short signal);
short FPH_1000(short signal);
short filtrerCascadeIIR(int noCorde, short x);
*/
void init_w();
short sat_16bits(int x);

