/*
 * bitrev_index.h
 *
 *  Created on: Apr 5, 2018
 *      Author: simon
 */

#ifndef INCLUDE_BITREV_INDEX_H_
#define INCLUDE_BITREV_INDEX_H_


void bitrev_index(short *index, int n)  ;


#endif /* INCLUDE_BITREV_INDEX_H_ */
