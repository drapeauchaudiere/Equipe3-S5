/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

#ifndef GPIO_H
#define	GPIO_H

#include "definitions.h"

void GPIO_init(void);

#endif	/* GPIO_H */

