/*
 * effects.c
 *
 *  Created on: Feb 18, 2018
 *      Author: simon
 */

#include "effects.h"

/****************************************************************************
    Private global variables :
****************************************************************************/
EFFECT_CONFIG_U effectConfiguration = {0};
